# change default from rsh to ssh for cvs command
export CVS_RSH=${CVS_RSH-ssh}