#!/bin/bash

while getopts "H:C:w:c:h" OPT; do
	case $OPT in
		"H") host=$OPTARG;;
		"C") community=$OPTARG;;
		"w") warning=$OPTARG;;
		"c") critical=$OPTARG;;
		"h") 
			echo "Syntax:  $0 -H <host address> -C <snmp community> -w <pct used warning> -c <pct used critical>"
			exit 3
		;;
	esac
done

output=$(snmpget -v 2c -c $community $host .1.3.6.1.4.1.12356.101.4.1.6.0 .1.3.6.1.4.1.12356.101.4.1.7.0)
used=$(echo "$output" |awk 'FNR==1 {print $4}')
total=$(echo "$output" |awk 'FNR==2 {print $4}')

pct=$(echo "scale=0; $used*100/$total" | bc)

if [[ $pct -ge $critical ]]; then
	status=2
	message="CRITICAL"
else if [[ $pct -ge $warning ]]; then
   	status=1
   	message="WARNING"
else
   	status=0
   	message="OK"
fi
fi

echo "$message - $pct% disk used ( $used MiB used from $total MiB total ) | pct_used=$pct;$warning;$critical mb_used=$used mb_total=$total"
exit $status
