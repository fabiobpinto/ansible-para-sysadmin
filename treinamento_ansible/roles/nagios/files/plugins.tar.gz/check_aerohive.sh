#!/bin/bash 

re='^[0-9]+$'

while getopts "H:C:m:w:c:h" OPT; do
	case $OPT in
		"H") host=$OPTARG;;
		"C") community=$OPTARG;;
		"m") mode=$OPTARG;;
		"w") warning=$OPTARG;;
		"c") critical=$OPTARG;;
		"h") 
			echo "Syntax:  $0 -H <host address> -C <snmp community> -m <mode> -w <pct used warning> -c <pct used critical>"
			exit 3
		;;
	esac
done

check_model (){
	model_string="HiveOS"
	model_oid="1.3.6.1.2.1.1.1.0"
	model=$(snmpget -t 120 -v 2c -c $community $host $model_oid | awk '{print $4,$5,$6,$7,$8}')
	echo "Aerohive AP Model: $model"
	exit 0
}

check_cpu (){
	cpu_oid=".1.3.6.1.4.1.26928.1.2.3.0"
	cpu_used=$(snmpget -t 120 -v 2c -c $community $host $cpu_oid | awk '{print $4}')
	if ! [[ $cpu_used =~ $re ]] ; then
   		echo "Unknown error: Output value is not a number" 
   		exit 3
	fi
	if [[ $cpu_used -ge $critical ]]; then
		status=2
		message="Critical -"
	else if [[ $cpu_used -ge $warning ]]; then
   		status=1
   		message="Warning -"
	else
   		status=0
   		message="OK -"
	fi
	fi
	
	echo "CPU $message Usage: $cpu_used% | cpu=$cpu_used%;$warning;$critical"
	exit $status
}

check_memory (){
	memory_oid=".1.3.6.1.4.1.26928.1.2.4.0"
	memory_used=$(snmpget -t 120 -v 2c -c $community $host $memory_oid | awk '{print $4}')
	if ! [[ $memory_used =~ $re ]] ; then
   		echo "Unknown error: Output value is not a number" 
   		exit 3
	fi
	if [[ $memory_used -ge $critical ]]; then
		status=2
		message="Critical -"
	else if [[ $memory_used -ge $warning ]]; then
   		status=1
   		message="Warning -"
	else
   		status=0
   		message="OK -"
	fi
	fi
	
	echo "MEMORY $message Usage: $memory_used% | memory=$memory_used%;$warning;$critical"
	exit $status
}

check_clients (){
	clients_oid=".1.3.6.1.4.1.26928.1.2.9.0"
	clients=$(snmpget -t 120 -v 2c -c $community $host $clients_oid | awk '{print $4}')
	if ! [[ $clients =~ $re ]] ; then
   		echo "Unknown error: Output value is not a number" 
   		exit 3
	fi
	if [[ $clients -ge $critical ]]; then
		status=2
		message="Critical -"
	else if [[ $clients -ge $warning ]]; then
   		status=1
   		message="Warning -"
	else
   		status=0
   		message="OK -"
	fi
	fi
	
	echo "CLIENTS $message $clients | clients=$clients;$warning;$critical"
	exit $status
}


case $mode in
	"cpu") check_cpu;;
	"memory") check_memory;;
	"clients") check_clients;;
	"model") check_model;;
	"*") 
		echo "Available modes: cpu memory clients model"
		exit 3
	;;
esac
