#!/bin/bash

temp_oid=".1.3.6.1.4.1.38783.3.9.0"
degcel="\0260C"

while getopts "H:C:w:c:h" OPT; do
	case $OPT in
		"H") host=$OPTARG;;
		"C") community=$OPTARG;;
		"w") warning=$OPTARG;;
		"c") critical=$OPTARG;;
		"h") 
			echo "Syntax: $0 -H <host address> -C <snmp community> -w <warning> -c <critical>"
			exit 3
		;;
	esac
done

raw_temp=$(snmpget -t 50 -v 1 -c $community $host $temp_oid |awk '{print $4}')
num=$(echo "scale=0; $raw_temp/10" |bc)
float=$(echo "scale=1; $raw_temp/10" |bc)
if [ -n "$num" ];then
	if [[ $num -ge $critical ]]; then
		status=2
		message="Critical -"
		else if [[ $num -ge $warning ]]; then
   			status=1
   			message="Warning -"
		else
   			status=0
   			message="OK -"
		fi
	fi
else
	status=3
	message="Unknown Error -"
fi

echo -e "$message Temperature: $float\xc2\xb0C| temperature=$float;$warning;$critical"
exit $status
